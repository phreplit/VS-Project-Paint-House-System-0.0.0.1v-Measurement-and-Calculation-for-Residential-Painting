﻿
//  Author: PHNO - Technologist | Postgraduate in Photovoltaic Solar Energy
//  Release Date: 21/09/2024
//  Version: 0.0.0.1v
//  Replit: @PHNO, @PHREPLIT
//  E-mail: phreplit@gmail.com

// Software: Paint House - System - 0.0.0.1v - Measurement and Calculation for Residential Painting, with GUI [graphical interface] and compilation in desktop environment.

using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using static System.Windows.Forms.VisualStyles.VisualStyleElement;

namespace $safeprojectname$
{
    public partial class Form1 : Form
    {
        public Form1()
        {
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero1) && int.TryParse(textBox2.Text, out int numero2))
            {
                int result = numero1 * numero2;

                textBox3.Text = ("" + result);
            }
            else
            {
                textBox3.Text = "Error. enter required field.";
            }
        }

        private void button2_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox1.Text, out int numero1) && int.TryParse(textBox2.Text, out int numero2))
            {
                this.Text = "Paint House - System - 0.0.0.1v - Measurement and Calculation for Residential Painting";


                // class, method
                textBox1.Clear();
                textBox2.Clear();
                textBox3.Clear(); // call clear method
            }
            else
            {
                textBox3.Text = "Error. nothing to clear.";
            }

        }

        private void button3_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int numero4)) // && int.TryParse(textBox5.Text, out int numero5) && int.TryParse(textBox6.Text, out int numero6))
            {
                int v2 = 360; // amount of paint per 1 square meter
                int resultado = numero4 * v2; // amount of paint per(n) so many m²
                double qtdtinta = 3600; // 1 can of paint has 3600ml(3,6)
                double resultado2 = resultado / qtdtinta; // amount of paint cans


                textBox5.Text = ("" + resultado);
                textBox6.Text = ("" + resultado2);
            }
            else
            {
                textBox5.Text = "Error. enter required field.";
                textBox6.Text = "Error. enter required field.";
            }

        }

        private void button4_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox4.Text, out int numero4) && int.TryParse(textBox5.Text, out int numero5))
            {
                this.Text = "Paint House - System - 0.0.0.1v - Measurement and Calculation for Residential Painting";


                // class, method
                textBox4.Clear();
                textBox5.Clear();
                textBox6.Clear();  // call clear method
            }
            else
            {
                textBox5.Text = "Error. nothing to clear.";
                textBox6.Text = "Error. nothing to clear.";
            }
        }

        private void button16_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox11.Text, out int numero11) && int.TryParse(textBox12.Text, out int numero12))
            {
                this.Text = "Paint House - System - 0.0.0.1v - Measurement and Calculation for Residential Painting";


                // class, method
                textBox11.Clear();
                textBox12.Clear();
                textBox13.Clear();  // call clear method
            }
            else
            {
                textBox13.Text = "Error. nothing to clear.";
            }
        }

        private void button12_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox11.Text, out int numero11) && int.TryParse(textBox12.Text, out int numero12))
            {
                int sum = numero11 + numero12;

                textBox13.Text = ("" + sum);
            }
            else
            {
                textBox13.Text = "Error. enter required field.";
            }

        }

        private void button13_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox11.Text, out int numero11) && int.TryParse(textBox12.Text, out int numero12))
            {
                int sub = numero11 - numero12;

                textBox13.Text = ("" + sub);
            }
            else
            {
                textBox13.Text = "Error. enter required field.";
            }
        }

        private void button14_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox11.Text, out int numero11) && int.TryParse(textBox12.Text, out int numero12))
            {
                int div = numero11 / numero12;

                textBox13.Text = ("" + div);
            }
            else
            {
                textBox13.Text = "Error. enter required field.";
            }
        }

        private void button15_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox11.Text, out int numero11) && int.TryParse(textBox12.Text, out int numero12))
            {
                int mult = numero11 * numero12;

                textBox13.Text = ("" + mult);
            }
            else
            {
                textBox13.Text = "Error. enter required field.";
            }
        }

        private void button5_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox7.Text, out int numero7))
            {
                int v2 = 3; // 3600ml(3.6) divided by 3 will be 1200ml equivalent to 3 coats
                int resultado3 = numero7 * v2; // coat

                textBox8.Text = ("" + resultado3);
            }
            else
            {
                textBox8.Text = "Error. enter required field.";
            }
        }

        private void button6_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox7.Text, out int numero7) && int.TryParse(textBox8.Text, out int numero8))
            {
                this.Text = "Paint House - System - 0.0.0.1v - Measurement and Calculation for Residential Painting";


                // class, method
                textBox7.Clear();
                textBox8.Clear();
            }
            else
            {
                textBox8.Text = "Error. nothing to clear.";
            }
        }

        private void button7_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox9.Text, out int numero9))
            {
                int v2 = 3; // 3600ml(3.6) divided by 3 will be 1200ml equivalent to 3 coats
                int mq1 = 360; // 1 square meter
                int lata1 = 3600; // 1 can of paint
                int resultado4 = numero9 * v2; // coat
                int calcqtdlitro = numero9 * lata1;  // amount of paint
                int calcmq = calcqtdlitro / mq1;  // square meter


                textBox10.Text = ("" + calcmq);
                textBox14.Text = ("" + resultado4);
            }
            else
            {
                textBox10.Text = "Error. enter required field.";
                textBox14.Text = "Error. enter required field.";
            }
        }

        private void button8_Click(object sender, EventArgs e)
        {
            if (int.TryParse(textBox9.Text, out int numero9) && int.TryParse(textBox10.Text, out int numero10))
            {
                this.Text = "Paint House - System - 0.0.0.1v - Measurement and Calculation for Residential Painting";


                // class, method
                textBox9.Clear();
                textBox10.Clear();
                textBox14.Clear();
            }
            else
            {
                textBox10.Text = "Error. nothing to clear.";
                textBox14.Text = "Error. nothing to clear.";
            }
        }

        private void button9_Click(object sender, EventArgs e)
        {
            this.Text = "Info";
            // classe, metodo, string(texto)
            MessageBox.Show("Info\n"
            + "\nThis software was developed with integer variables so it does not accept numbers with commas e.g.: 2.90 meters change to 3 meters.\n"
            + "\nTo calculate the Area of ​​a Wall [Square Meter] - Regular Size Wall [4 equal sides] - we will calculate the height multiplied by the width.\n"
            + "\nTo Calculate Painting with Undiluted Paint:\n"
            + "\nWith Base on a 3.6L can of paint and with base on a wall with (H 2.70 meters x W 3.70 meters) we have that H x W = 10 Square Meters, and then we have that 1 can of paint with 3600ml of paint divided by 10 will have 360ml for each 1 Square Meter, this will be the calculation standard 360ml = 1 Square Meter, so we have that Any (N) square meters x 360ml = (N) liters of paint and this result divided by 3600ml will be equal to (N) quantity of cans of paint.\n"
            + "\nTo calculate a painting hand (one coat): \n"
            + "\nTo paint one coat, we have that a tray of paint has 1000ml as a reference per coat, and a can of paint has 3600ml, so we have that a  can of paint has 1200ml per coat since 1200ml vs 3 = 3600ml (3.6L). One coat is equivalent to a complete painting of a wall. Generally, two to three coats are necessary to paint a wall.\n");
        }

        private void button10_Click(object sender, EventArgs e)
        {
            this.Text = "About";
            MessageBox.Show("About\n" + "\nSoftware: Paint House - System - 0.0.0.1v - Measurement and Calculation for Residential Painting \n" + "\nAuthor: PHNO" + "\nRelease Date: 20/09/2024" + "\nVersion: 0.0.0.1v" + "\nReplit: @PHNO, @PHREPLIT" + "\nE-mail: phreplit@gmail.com");
        }

        private void button11_Click(object sender, EventArgs e)
        {
            this.Text = "Paint House - System - 0.0.0.1v - Measurement and Calculation for Residential Painting";


            // class, method
            textBox1.Clear();
            textBox2.Clear();
            textBox3.Clear(); // call clear method
            textBox4.Clear();
            textBox5.Clear();
            textBox6.Clear();
            textBox7.Clear();
            textBox8.Clear();
            textBox9.Clear();
            textBox10.Clear();
            textBox11.Clear();
            textBox12.Clear();
            textBox13.Clear();
            textBox14.Clear();
        }
    }
}

